﻿select * from ACCOUNTS

delete from ACCOUNTS where username = 'admin'