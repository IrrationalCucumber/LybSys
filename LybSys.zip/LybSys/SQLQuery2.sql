﻿select * from TRANSACTIONS

insert into TRANSACTIONS (bookId,bookTitle, dateAdded) 
values (1, 'test', '2023-03-19')
